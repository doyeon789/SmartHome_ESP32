

#define F_CPU 16000000UL
#define sbi(PORTX,bitX) PORTX|=(1<<bitX)
#define cbi(PORTX,bitX) PORTX&=~(1<<bitX)
#define tbi(PORTX,bitX) PORTX^=(1<<bitX)

#include <avr/io.h>
#include <util/delay.h>

void get_dht11();
void request();
int response();
char receive_data();
void uart1_tx(char data);
void uart1_tx_int(int intdata);

char DHT11_data = 0,hum_int,hum_dec,tem_int,tem_dec,parity;

int main(void)
{
	//UART
	UCSR1B = (1<<TXEN1);
	UCSR1C = (1<<UCSZ11)|(1<<UCSZ10);
	UBRR1H = 0;
	UBRR1L = 103;	//9600bps
	
	while(1)
	{
		get_dht11();
		if ((hum_int + hum_dec + tem_int + tem_dec) != parity)
		{
			uart1_tx('e');
		}
		else
		{
			uart1_tx('$');
			uart1_tx(',');
			uart1_tx_int(tem_int);
			uart1_tx('.');
			uart1_tx_int(tem_dec);
			uart1_tx(',');
			uart1_tx_int(hum_int);
			uart1_tx('.');
			uart1_tx_int(hum_dec);
			uart1_tx(',');
		}
		_delay_ms(400);
	}
}

void get_dht11()
{
	request();						//Host send a start signal
	if(response() != 1)				//DHT11 response
	{
		hum_int = receive_data();	//Humidity integer
		hum_dec = receive_data();	//Humidity decimal
		tem_int = receive_data();	//Temporature integer
		tem_dec = receive_data();	//Temporature decimal
		parity = receive_data();	//parity
	}
	else							//DHT11 response error
	{
		//do something
	}
}

void request()
{
	sbi(DDRF,7);		//output
	cbi(PORTF,7);		//low
	_delay_ms(20);		//more than 18ms
	sbi(PORTF,7);		//high
}

int response()
{
	cbi(DDRF,7);			//input
	_delay_us(39);			//pulled wait 20~40us
	if((PINF & (1<<7)))		//response signal check
	return 1;
	_delay_us(80);			//wait 80us
	if(!(PINF & (1<<7)))	//pulled ready output check
	return 1;
	_delay_us(80);			//wait 80us
}

char receive_data()
{
	for (int q=0; q<8; q++)
	{
		while((PINF & (1<<7)) == 0); //50us signal wait
		_delay_us(30);
		if(PINF & (1<<7))			//greater than 30ms -> HIGH
		DHT11_data = (DHT11_data<<1)|(0x01);
		else						//less than 30ms -> LOW
		DHT11_data = (DHT11_data<<1);
		while(PINF & (1<<7));
	}
	return DHT11_data;
}



void uart1_tx(char data)
{
	while(!(UCSR1A&(1<<UDRE1)));
	UDR1 = data;
}

void uart1_tx_int(int intdata)
{
	int temp_intdata = 0;
	
	temp_intdata = intdata/10;
	uart1_tx(temp_intdata+48);
	temp_intdata = intdata%10;
	uart1_tx(temp_intdata+48);
}







